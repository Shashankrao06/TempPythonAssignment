import unittest
import numpy as np


# ============================================================
# QUESTION 1: Difference matrix and vector operations
# ============================================================

def construct_D(n):
    """
    Build the difference matrix D of shape (n, n-1).
    n -- number of rows (at least 2)
    returns a float64 numpy array
    """
    D = np.zeros((n, n - 1), dtype=np.float64)

    for col in range(n - 1):
        D[col, col] = -1.0
        D[col + 1, col] = 1.0

    return D


def subvector(x, i, j):
    """
    Get the subvector x[i:j] using 1-based inclusive indices.
    x -- 1-D numpy array
    i -- start index (1-based)
    j -- end index (1-based, inclusive)
    returns the subvector as a numpy array
    """
    return x[i - 1:j]


# ============================================================
# QUESTION 2: Token embedding differences
# ============================================================

def compute_embedding_differences():
    """
    Build 6 random token embeddings (768-dim each) and return D.T @ X.
    returns a float64 array of shape (5, 768)
    """
    rng = np.random.default_rng(0)
    X = rng.standard_normal((6, 768)).astype(np.float64)
    D = construct_D(6)
    return D.T @ X


# ============================================================
# QUESTION 3: Layer normalization
# ============================================================

def layer_norm(e, gamma, beta, eps=1e-5):
    """
    Layer normalization for a single activation vector.
    e -- 1-D activation vector
    gamma -- scale vector, same shape as e
    beta -- offset vector, same shape as e
    eps -- small constant for numerical stability
    returns the normalized vector (same shape as e)

    (np.mean, np.var, np.std are not used here, as per the instructions)
    """
    n = e.size

    m = np.sum(e) / n               # mean
    centered = e - m
    v = np.sum(centered ** 2) / n   # variance

    out = (centered / np.sqrt(v + eps)) * gamma + beta
    return out


# ============================================================
# UNIT TESTS: QUESTION 1
# ============================================================

class TestQuestion1(unittest.TestCase):

    def setUp(self):
        self.x = np.array([1, 4, 9, 16, 25, 36], dtype=np.float64)
        self.D = construct_D(6)

    def test_construct_D_shape(self):
        # part a: D should be n x (n-1) and float64
        self.assertEqual(self.D.shape, (6, 5))
        self.assertEqual(self.D.dtype, np.float64)

    def test_construct_D_values(self):
        first_col = np.array([-1, 1, 0, 0, 0, 0], dtype=np.float64)
        self.assertTrue(np.allclose(self.D[:, 0], first_col))

    def test_xTD(self):
        # part a: x transpose D
        expected = np.array([3, 5, 7, 9, 11], dtype=np.float64)
        result = self.x @ self.D
        self.assertTrue(np.allclose(result, expected, atol=1e-12))

    def test_subvector(self):
        # part b: x2:5
        expected = np.array([4, 9, 16, 25], dtype=np.float64)
        result = subvector(self.x, 2, 5)
        self.assertTrue(np.allclose(result, expected))

    def test_d_equals_DTx(self):
        # part c: d = x2:6 - x1:5 should equal D.T @ x
        d = subvector(self.x, 2, 6) - subvector(self.x, 1, 5)
        self.assertTrue(np.allclose(d, self.D.T @ self.x, atol=1e-12))


# ============================================================
# UNIT TESTS: QUESTION 2
# ============================================================

class TestQuestion2(unittest.TestCase):

    def test_shape(self):
        result = compute_embedding_differences()
        self.assertEqual(result.shape, (5, 768))
        self.assertEqual(result.dtype, np.float64)

    def test_values(self):
        rng = np.random.default_rng(0)
        X = rng.standard_normal((6, 768)).astype(np.float64)
        expected = X[1:, :] - X[:-1, :]

        result = compute_embedding_differences()
        self.assertTrue(np.allclose(result, expected, atol=1e-12))


# ============================================================
# UNIT TESTS: QUESTION 3
# ============================================================

class TestQuestion3(unittest.TestCase):

    def setUp(self):
        rng = np.random.default_rng(0)
        self.e = rng.standard_normal(768).astype(np.float64)
        self.gamma = rng.standard_normal(768).astype(np.float64)
        self.beta = rng.standard_normal(768).astype(np.float64)
        self.eps = 1e-5

    def test_matches_reference_formula(self):
        # (i) compare against a reference version using np.mean / np.var
        result = layer_norm(self.e, self.gamma, self.beta, self.eps)

        m = np.mean(self.e)
        v = np.var(self.e)
        expected = ((self.e - m) / np.sqrt(v + self.eps)) * self.gamma + self.beta

        self.assertTrue(np.allclose(result, expected, rtol=1e-10, atol=1e-10))

    def test_mean_zero_var_scaled(self):
        # (ii) with gamma=1, beta=0: mean ~ 0, variance ~ v / (v + eps)
        gamma = np.ones(768, dtype=np.float64)
        beta = np.zeros(768, dtype=np.float64)

        result = layer_norm(self.e, gamma, beta, self.eps)

        v = np.var(self.e)
        expected_var = v / (v + self.eps)

        self.assertAlmostEqual(float(np.mean(result)), 0.0, delta=1e-10)
        self.assertAlmostEqual(float(np.var(result)), float(expected_var), delta=1e-10)


# ============================================================
# MAIN PROGRAM
# ============================================================

if __name__ == "__main__":
    print("QUESTION 1")
    x = np.array([1, 4, 9, 16, 25, 36], dtype=np.float64)
    D = construct_D(6)
    print("D =\n", D)
    print("x.T @ D =", x @ D)
    print("x2:5 =", subvector(x, 2, 5))

    d = subvector(x, 2, 6) - subvector(x, 1, 5)
    print("d =", d)
    print("D.T @ x =", D.T @ x)

    print("\nQUESTION 2")
    diffs = compute_embedding_differences()
    print("D.T @ X shape:", diffs.shape)

    print("\nQUESTION 3")
    rng = np.random.default_rng(0)
    e = rng.standard_normal(768).astype(np.float64)
    gamma = np.ones(768, dtype=np.float64)
    beta = np.zeros(768, dtype=np.float64)

    out = layer_norm(e, gamma, beta)
    print("output shape:", out.shape)
    print("output mean:", np.mean(out))
    print("output variance:", np.var(out))

    print("\nRUNNING UNIT TESTS")
    unittest.main(argv=["first-arg-is-ignored"], exit=False)
