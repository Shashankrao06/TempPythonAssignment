import numpy as np


def construct_D(n):
    """
    Build the difference matrix D of shape (n, n-1).
    (same as question 1, repeated here so this file runs on its own)
    """
    D = np.zeros((n, n - 1), dtype=np.float64)

    for col in range(n - 1):
        D[col, col] = -1.0
        D[col + 1, col] = 1.0

    return D


# part a: 6 token embeddings, each of size 768
rng = np.random.default_rng(0)
X = rng.standard_normal((6, 768)).astype(np.float64)

D = construct_D(6)
diffs = D.T @ X

if __name__ == "__main__":
    print("X shape:", X.shape)
    print("D shape:", D.shape)
    print("D.T @ X shape:", diffs.shape)
    print("D.T @ X =\n", diffs)
