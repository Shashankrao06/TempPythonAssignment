import unittest
import numpy as np


def construct_D(n):
    """
    Build the difference matrix D of shape (n, n-1).
    n -- number of rows (at least 2)
    returns a float64 numpy array
    """
    D = np.zeros((n, n - 1), dtype=np.float64)

    for col in range(n - 1):
        D[col, col] = -1.0
        D[col + 1, col] = 1.0

    return D


def subvector(x, i, j):
    """
    Get the subvector x[i:j] using 1-based inclusive indices.
    x -- 1-D numpy array
    i -- start index (1-based)
    j -- end index (1-based, inclusive)
    returns the subvector as a numpy array
    """
    return x[i - 1:j]


# part a, b, c worked out here
x = np.array([1, 4, 9, 16, 25, 36], dtype=np.float64)
D = construct_D(6)

xTD = x @ D

x2_5 = subvector(x, 2, 5)

d = subvector(x, 2, 6) - subvector(x, 1, 5)
DTx = D.T @ x


class TestQuestion1(unittest.TestCase):

    def setUp(self):
        self.x = np.array([1, 4, 9, 16, 25, 36], dtype=np.float64)
        self.D = construct_D(6)

    def test_construct_D_shape(self):
        # part a: D should be n x (n-1) and float64
        self.assertEqual(self.D.shape, (6, 5))
        self.assertEqual(self.D.dtype, np.float64)

    def test_construct_D_values(self):
        first_col = np.array([-1, 1, 0, 0, 0, 0], dtype=np.float64)
        self.assertTrue(np.allclose(self.D[:, 0], first_col))

    def test_xTD(self):
        # part a: x transpose D
        expected = np.array([3, 5, 7, 9, 11], dtype=np.float64)
        result = self.x @ self.D
        self.assertTrue(np.allclose(result, expected, atol=1e-12))

    def test_subvector(self):
        # part b: x2:5
        expected = np.array([4, 9, 16, 25], dtype=np.float64)
        result = subvector(self.x, 2, 5)
        self.assertTrue(np.allclose(result, expected))

    def test_d_equals_DTx(self):
        # part c: d = x2:6 - x1:5 should equal D.T @ x
        d = subvector(self.x, 2, 6) - subvector(self.x, 1, 5)
        self.assertTrue(np.allclose(d, self.D.T @ self.x, atol=1e-12))


if __name__ == "__main__":
    print("D =\n", D)
    print("x.T @ D =", xTD)
    print("x2:5 =", x2_5)
    print("d =", d)
    print("D.T @ x =", DTx)

    unittest.main(argv=["first-arg-is-ignored"], exit=False)
