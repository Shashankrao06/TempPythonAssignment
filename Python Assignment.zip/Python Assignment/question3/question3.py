import unittest
import numpy as np


def layer_norm(e, gamma, beta, eps=1e-5):
    """
    Layer normalization for a single activation vector.
    e -- 1-D activation vector
    gamma -- scale vector, same shape as e
    beta -- offset vector, same shape as e
    eps -- small constant for numerical stability
    returns the normalized vector (same shape as e)

    (np.mean, np.var, np.std are not used here, as per the instructions)
    """
    n = e.size

    m = np.sum(e) / n           # mean
    centered = e - m
    v = np.sum(centered ** 2) / n   # variance

    out = (centered / np.sqrt(v + eps)) * gamma + beta
    return out


class TestQuestion3(unittest.TestCase):

    def setUp(self):
        rng = np.random.default_rng(0)
        self.e = rng.standard_normal(768).astype(np.float64)
        self.gamma = rng.standard_normal(768).astype(np.float64)
        self.beta = rng.standard_normal(768).astype(np.float64)
        self.eps = 1e-5

    def test_matches_reference_formula(self):
        # (i) compare against a reference version using np.mean / np.var
        result = layer_norm(self.e, self.gamma, self.beta, self.eps)

        m = np.mean(self.e)
        v = np.var(self.e)
        expected = ((self.e - m) / np.sqrt(v + self.eps)) * self.gamma + self.beta

        self.assertTrue(np.allclose(result, expected, rtol=1e-10, atol=1e-10))

    def test_mean_zero_var_scaled(self):
        # (ii) with gamma=1, beta=0: mean ~ 0, variance ~ v / (v + eps)
        gamma = np.ones(768, dtype=np.float64)
        beta = np.zeros(768, dtype=np.float64)

        result = layer_norm(self.e, gamma, beta, self.eps)

        v = np.var(self.e)
        expected_var = v / (v + self.eps)

        self.assertAlmostEqual(float(np.mean(result)), 0.0, delta=1e-10)
        self.assertAlmostEqual(float(np.var(result)), float(expected_var), delta=1e-10)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    e = rng.standard_normal(768).astype(np.float64)
    gamma = np.ones(768, dtype=np.float64)
    beta = np.zeros(768, dtype=np.float64)

    out = layer_norm(e, gamma, beta)
    print("output shape:", out.shape)
    print("output mean:", np.mean(out))
    print("output variance:", np.var(out))

    unittest.main(argv=["first-arg-is-ignored"], exit=False)
